# Feelyo Works Website

This repository contains the first static website for **feelyoworks.com**.
It is designed to be deployed with **Cloudflare Pages** from the `main` branch.

## Files

```txt
.
├── index.html
├── styles.css
├── 404.html
├── _headers
├── .gitignore
└── README.md
```

## Cloudflare Pages settings

Use these settings when connecting this repository to Cloudflare Pages:

| Setting | Value |
|---|---|
| Framework preset | None |
| Production branch | main |
| Build command | exit 0 |
| Build output directory | / |
| Root directory | Leave blank |

If Cloudflare does not accept `/` as the output directory, put the site files inside a `public` folder and set the build output directory to `public`.

## Deploy from local terminal

Replace the remote URL with your own GitHub repository URL.

```bash
git clone https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
cd YOUR_REPOSITORY

# Copy these files into the repository folder, then run:
git add .
git commit -m "Initial Feelyo Works website"
git branch -M main
git push -u origin main
```

## Deploy from GitHub web UI

1. Open your GitHub repository.
2. Select **Add file** > **Upload files**.
3. Upload all files in this starter package.
4. Commit directly to the `main` branch.
5. Go back to Cloudflare Pages and connect the repository.

## Custom domain

After the first deployment succeeds, connect these domains in Cloudflare Pages:

- `feelyoworks.com`
- `www.feelyoworks.com`

Recommended final behavior:

- Main domain: `https://feelyoworks.com`
- Optional redirect: `https://www.feelyoworks.com` -> `https://feelyoworks.com`

## Edit content

Main page text is in `index.html`.
Visual design is in `styles.css`.
